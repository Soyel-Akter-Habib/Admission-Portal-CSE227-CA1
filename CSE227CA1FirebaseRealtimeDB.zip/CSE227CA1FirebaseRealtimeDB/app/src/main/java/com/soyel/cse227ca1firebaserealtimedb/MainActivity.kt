package com.soyel.cse227ca1firebaserealtimedb

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var name: EditText
    lateinit var reg : EditText
    lateinit var lc:EditText
    lateinit var save :Button
    lateinit var show:Button
    lateinit var tv_name: TextView
    lateinit var tv_reg :TextView
    lateinit var tv_lc:TextView

    lateinit var nm:String
    lateinit var rg:String

    lateinit var l:String
lateinit var lin :LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        name = findViewById(R.id.name)
        reg = findViewById(R.id.reg)
        lc=findViewById(R.id.lc)
        save = findViewById(R.id.save)
        show = findViewById(R.id.show)

        tv_name = findViewById(R.id.tv_name)
        tv_reg=findViewById(R.id.tv_reg)
        tv_lc = findViewById(R.id.tv_lc)
        lin = findViewById(R.id.lin_lay)




         nm = name.text.toString()
         rg = reg.text.toString()
         l = lc.text.toString()

        save.setOnClickListener {
            name.text.clear()
            reg.text.clear()
            lc.text.clear()
            Toast.makeText(this,"Data Saved Successfully..",Toast.LENGTH_SHORT).show()
        }

        show.setOnClickListener {
//            tv_name.text = nm.toString()
//            tv_reg.text=rg.toString()
//            tv_lc.text=l.toString()
            lin.visibility= View.VISIBLE


        }

    }
}